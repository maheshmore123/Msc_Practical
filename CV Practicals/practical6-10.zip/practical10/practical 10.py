import cv2
import numpy as np

image_path = "C:/Users/Admin/Downloads/girl.jpg"
background_path = "C:/Users/Admin/Downloads/home.jpeg"
output_path = "C:/Users/Admin/Downloads/result.jpeg"
def grabcut_matting(image_path, background_path, output_path):
    # Load the input image and background
    img = cv2.imread(image_path)
    bg = cv2.imread(background_path)
    # Check if images are loaded successfully
    if img is None:
        print(f"Error loading image: {image_path}")
        return
    if bg is None:
        print(f"Error loading background: {background_path}")
        return
    # Resize background to match the input image size
    bg = cv2.resize(bg, (img.shape[1], img.shape[0]))
    # Create initial mask
    mask = np.zeros(img.shape[:2], np.uint8)
    # Define a rectangle containing the foreground object (manually adjustable)
    rect = (50, 50, img.shape[1] - 100, img.shape[0] - 100)
    # Allocate memory for models (needed by GrabCut)
    bgdModel = np.zeros((1, 65), np.float64)
    fgdModel = np.zeros((1, 65), np.float64)
    # Apply GrabCut
    cv2.grabCut(img, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)
    # Prepare the mask for compositing
    mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
    mask3 = cv2.merge([mask2, mask2, mask2])
    # Extract the foreground
    foreground = img * mask3
    cv2.imshow('Foreground', foreground)
    # Extract the background where the mask is 0
    background = bg * (1 - mask3)
    # Combine foreground and new background
    result = cv2.add(foreground, background)
    # Save the result to output path
    cv2.imwrite(output_path, result)
    cv2.imshow('Composited Image', result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
# Call the function with paths
grabcut_matting(image_path, background_path, output_path)
